
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.somethinguseful.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.somethinguseful.block.StoneGlassBlock;
import net.mcreator.somethinguseful.block.HeavyIronBlockBlock;
import net.mcreator.somethinguseful.block.HeavyGoldBlockBlock;
import net.mcreator.somethinguseful.block.HeavyCopperBlockBlock;
import net.mcreator.somethinguseful.block.GhostStoneBlock;
import net.mcreator.somethinguseful.block.GhostDirtBlock;
import net.mcreator.somethinguseful.block.GhostDeepBlock;
import net.mcreator.somethinguseful.block.DirtGlassBlock;
import net.mcreator.somethinguseful.block.DeepGlassBlock;
import net.mcreator.somethinguseful.block.CompressorBlock;
import net.mcreator.somethinguseful.block.CompactObsidianBlock;
import net.mcreator.somethinguseful.SomethingUsefulMod;

public class SomethingUsefulModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, SomethingUsefulMod.MODID);
	public static final RegistryObject<Block> COMPRESSOR = REGISTRY.register("compressor", () -> new CompressorBlock());
	public static final RegistryObject<Block> HEAVY_IRON_BLOCK = REGISTRY.register("heavy_iron_block", () -> new HeavyIronBlockBlock());
	public static final RegistryObject<Block> HEAVY_GOLD_BLOCK = REGISTRY.register("heavy_gold_block", () -> new HeavyGoldBlockBlock());
	public static final RegistryObject<Block> HEAVY_COPPER_BLOCK = REGISTRY.register("heavy_copper_block", () -> new HeavyCopperBlockBlock());
	public static final RegistryObject<Block> COMPACT_OBSIDIAN = REGISTRY.register("compact_obsidian", () -> new CompactObsidianBlock());
	public static final RegistryObject<Block> DIRT_GLASS = REGISTRY.register("dirt_glass", () -> new DirtGlassBlock());
	public static final RegistryObject<Block> STONE_GLASS = REGISTRY.register("stone_glass", () -> new StoneGlassBlock());
	public static final RegistryObject<Block> DEEP_GLASS = REGISTRY.register("deep_glass", () -> new DeepGlassBlock());
	public static final RegistryObject<Block> GHOST_DIRT = REGISTRY.register("ghost_dirt", () -> new GhostDirtBlock());
	public static final RegistryObject<Block> GHOST_STONE = REGISTRY.register("ghost_stone", () -> new GhostStoneBlock());
	public static final RegistryObject<Block> GHOST_DEEP = REGISTRY.register("ghost_deep", () -> new GhostDeepBlock());
}
