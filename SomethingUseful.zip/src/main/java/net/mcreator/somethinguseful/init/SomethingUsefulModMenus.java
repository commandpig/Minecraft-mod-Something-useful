
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.somethinguseful.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.somethinguseful.world.inventory.PhoneGUIMenu;
import net.mcreator.somethinguseful.world.inventory.CompressorGUIMenu;
import net.mcreator.somethinguseful.world.inventory.BinGUIMenu;
import net.mcreator.somethinguseful.SomethingUsefulMod;

public class SomethingUsefulModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, SomethingUsefulMod.MODID);
	public static final RegistryObject<MenuType<CompressorGUIMenu>> COMPRESSOR_GUI = REGISTRY.register("compressor_gui", () -> IForgeMenuType.create(CompressorGUIMenu::new));
	public static final RegistryObject<MenuType<BinGUIMenu>> BIN_GUI = REGISTRY.register("bin_gui", () -> IForgeMenuType.create(BinGUIMenu::new));
	public static final RegistryObject<MenuType<PhoneGUIMenu>> PHONE_GUI = REGISTRY.register("phone_gui", () -> IForgeMenuType.create(PhoneGUIMenu::new));
}
