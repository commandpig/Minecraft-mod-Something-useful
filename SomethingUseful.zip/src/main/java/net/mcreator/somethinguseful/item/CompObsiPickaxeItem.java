
package net.mcreator.somethinguseful.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.somethinguseful.init.SomethingUsefulModTabs;
import net.mcreator.somethinguseful.init.SomethingUsefulModBlocks;

public class CompObsiPickaxeItem extends PickaxeItem {
	public CompObsiPickaxeItem() {
		super(new Tier() {
			public int getUses() {
				return 2266;
			}

			public float getSpeed() {
				return 11f;
			}

			public float getAttackDamageBonus() {
				return 4f;
			}

			public int getLevel() {
				return 4;
			}

			public int getEnchantmentValue() {
				return 21;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(SomethingUsefulModBlocks.COMPACT_OBSIDIAN.get()));
			}
		}, 1, -2.8f, new Item.Properties().tab(SomethingUsefulModTabs.TAB_SOMETHING_USEFUL).fireResistant());
	}
}
