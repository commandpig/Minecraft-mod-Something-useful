package net.mcreator.somethinguseful.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.CommandSourceStack;

import net.mcreator.somethinguseful.init.SomethingUsefulModItems;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;

public class GiveMoneyProcedure {
	public static void execute(CommandContext<CommandSourceStack> arguments) {
		double gold = 0;
		double sliver = 0;
		double copper = 0;
		double money = 0;
		money = Math.round(DoubleArgumentType.getDouble(arguments, "money"));
		if (BoolArgumentType.getBool(arguments, "isCopper")) {
			copper = money;
		} else {
			gold = Math.floor(money / 64);
			money = money - gold * 64;
			sliver = Math.floor(money / 8);
			money = money - sliver * 8;
			copper = money;
		}
		if ((new Object() {
			public Entity getEntity() {
				try {
					return EntityArgument.getEntity(arguments, "playerName");
				} catch (CommandSyntaxException e) {
					e.printStackTrace();
					return null;
				}
			}
		}.getEntity()) instanceof Player _player) {
			ItemStack _setstack = new ItemStack(SomethingUsefulModItems.GOLD_COIN.get());
			_setstack.setCount((int) gold);
			ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
		}
		if ((new Object() {
			public Entity getEntity() {
				try {
					return EntityArgument.getEntity(arguments, "playerName");
				} catch (CommandSyntaxException e) {
					e.printStackTrace();
					return null;
				}
			}
		}.getEntity()) instanceof Player _player) {
			ItemStack _setstack = new ItemStack(SomethingUsefulModItems.SLIVER_COIN.get());
			_setstack.setCount((int) sliver);
			ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
		}
		if ((new Object() {
			public Entity getEntity() {
				try {
					return EntityArgument.getEntity(arguments, "playerName");
				} catch (CommandSyntaxException e) {
					e.printStackTrace();
					return null;
				}
			}
		}.getEntity()) instanceof Player _player) {
			ItemStack _setstack = new ItemStack(SomethingUsefulModItems.COPPER_COIN.get());
			_setstack.setCount((int) copper);
			ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
		}
	}
}
