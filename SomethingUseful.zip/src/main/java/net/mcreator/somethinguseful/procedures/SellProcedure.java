package net.mcreator.somethinguseful.procedures;

import net.minecraftforge.server.ServerLifecycleHooks;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.commands.CommandSourceStack;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;

public class SellProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, CommandContext<CommandSourceStack> arguments, Entity entity) {
		if (entity == null)
			return;
		String messages = "";
		messages = entity.getDisplayName().getString() + " wants to sell " + Math.round(DoubleArgumentType.getDouble(arguments, "number")) + " " + (ItemArgument.getItem(arguments, "item").getItem().getDefaultInstance()).getDisplayName().getString()
				+ " for " + Math.round(DoubleArgumentType.getDouble(arguments, "money")) + " coins.";
		if (BoolArgumentType.getBool(arguments, "location")) {
			messages = messages + " (location: " + Math.round(x) + ", " + Math.round(y) + ", " + Math.round(z) + ")";
		}
		if (!world.isClientSide()) {
			MinecraftServer _mcserv = ServerLifecycleHooks.getCurrentServer();
			if (_mcserv != null)
				_mcserv.getPlayerList().broadcastSystemMessage(Component.literal(messages), false);
		}
	}
}
