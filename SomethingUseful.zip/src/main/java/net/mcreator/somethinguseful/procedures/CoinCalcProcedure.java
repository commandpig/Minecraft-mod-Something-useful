package net.mcreator.somethinguseful.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class CoinCalcProcedure {
	public static void execute(CommandContext<CommandSourceStack> arguments, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level.isClientSide())
			_player.displayClientMessage(Component.literal(("" + (DoubleArgumentType.getDouble(arguments, "gold") * 64 + DoubleArgumentType.getDouble(arguments, "sliver") * 8 + DoubleArgumentType.getDouble(arguments, "copper")))), (false));
	}
}
