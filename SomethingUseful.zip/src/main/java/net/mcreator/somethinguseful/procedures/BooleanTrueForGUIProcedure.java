package net.mcreator.somethinguseful.procedures;

public class BooleanTrueForGUIProcedure {
	public static boolean execute() {
		return true;
	}
}
