
package net.mcreator.somethinguseful.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.Entity;

import net.mcreator.somethinguseful.procedures.GetTrashProcedure;
import net.mcreator.somethinguseful.init.SomethingUsefulModTabs;

public class TrashItem extends Item {
	public TrashItem() {
		super(new Item.Properties().tab(SomethingUsefulModTabs.TAB_SOMETHING_USEFUL).stacksTo(64).fireResistant().rarity(Rarity.COMMON).food((new FoodProperties.Builder()).nutrition(1).saturationMod(0f).alwaysEat()

				.build()));
	}

	@Override
	public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
		super.inventoryTick(itemstack, world, entity, slot, selected);
		GetTrashProcedure.execute(entity);
	}
}
