
package net.mcreator.somethinguseful.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

import net.mcreator.somethinguseful.init.SomethingUsefulModTabs;

public class CopperCoinItem extends Item {
	public CopperCoinItem() {
		super(new Item.Properties().tab(SomethingUsefulModTabs.TAB_SOMETHING_USEFUL).stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}
