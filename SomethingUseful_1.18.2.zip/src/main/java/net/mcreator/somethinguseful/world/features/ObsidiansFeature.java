
package net.mcreator.somethinguseful.world.features;

import net.minecraft.world.level.levelgen.placement.RarityFilter;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.placement.HeightRangePlacement;
import net.minecraft.world.level.levelgen.feature.configurations.ReplaceSphereConfiguration;
import net.minecraft.world.level.levelgen.feature.ReplaceBlobsFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.VerticalAnchor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.data.worldgen.placement.PlacementUtils;
import net.minecraft.data.worldgen.features.FeatureUtils;
import net.minecraft.core.Holder;

import java.util.Set;
import java.util.List;

public class ObsidiansFeature extends ReplaceBlobsFeature {
	public static ObsidiansFeature FEATURE = null;
	public static Holder<ConfiguredFeature<ReplaceSphereConfiguration, ?>> CONFIGURED_FEATURE = null;
	public static Holder<PlacedFeature> PLACED_FEATURE = null;

	public static Feature<?> feature() {
		FEATURE = new ObsidiansFeature();
		CONFIGURED_FEATURE = FeatureUtils.register("something_useful:obsidians", FEATURE, new ReplaceSphereConfiguration(Blocks.STONE.defaultBlockState(), Blocks.OBSIDIAN.defaultBlockState(), UniformInt.of(1, 2)));
		PLACED_FEATURE = PlacementUtils.register("something_useful:obsidians", CONFIGURED_FEATURE, List.of(HeightRangePlacement.triangle(VerticalAnchor.absolute(0), VerticalAnchor.absolute(64)), RarityFilter.onAverageOnceEvery(3)));
		return FEATURE;
	}

	public static Holder<PlacedFeature> placedFeature() {
		return PLACED_FEATURE;
	}

	public static final Set<ResourceLocation> GENERATE_BIOMES = null;

	public ObsidiansFeature() {
		super(ReplaceSphereConfiguration.CODEC);
	}
}
