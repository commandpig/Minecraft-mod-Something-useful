
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.somethinguseful.init;

import net.minecraftforge.network.IContainerFactory;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.AbstractContainerMenu;

import net.mcreator.somethinguseful.world.inventory.PhoneGUIMenu;
import net.mcreator.somethinguseful.world.inventory.CompressorGUIMenu;
import net.mcreator.somethinguseful.world.inventory.BinGUIMenu;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SomethingUsefulModMenus {
	private static final List<MenuType<?>> REGISTRY = new ArrayList<>();
	public static final MenuType<CompressorGUIMenu> COMPRESSOR_GUI = register("compressor_gui", (id, inv, extraData) -> new CompressorGUIMenu(id, inv, extraData));
	public static final MenuType<BinGUIMenu> BIN_GUI = register("bin_gui", (id, inv, extraData) -> new BinGUIMenu(id, inv, extraData));
	public static final MenuType<PhoneGUIMenu> PHONE_GUI = register("phone_gui", (id, inv, extraData) -> new PhoneGUIMenu(id, inv, extraData));

	private static <T extends AbstractContainerMenu> MenuType<T> register(String registryname, IContainerFactory<T> containerFactory) {
		MenuType<T> menuType = new MenuType<T>(containerFactory);
		menuType.setRegistryName(registryname);
		REGISTRY.add(menuType);
		return menuType;
	}

	@SubscribeEvent
	public static void registerContainers(RegistryEvent.Register<MenuType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new MenuType[0]));
	}
}
