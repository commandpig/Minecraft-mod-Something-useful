
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.somethinguseful.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.somethinguseful.item.TrashItem;
import net.mcreator.somethinguseful.item.SliverCoinItem;
import net.mcreator.somethinguseful.item.PhoneItem;
import net.mcreator.somethinguseful.item.HalfNetherrackItem;
import net.mcreator.somethinguseful.item.GoldCoinItem;
import net.mcreator.somethinguseful.item.CopperNuggetItem;
import net.mcreator.somethinguseful.item.CopperCoinItem;
import net.mcreator.somethinguseful.item.CompObsiPickaxeItem;
import net.mcreator.somethinguseful.item.CoalCoreItem;
import net.mcreator.somethinguseful.item.BinItem;
import net.mcreator.somethinguseful.SomethingUsefulMod;

public class SomethingUsefulModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, SomethingUsefulMod.MODID);
	public static final RegistryObject<Item> COMPRESSOR = block(SomethingUsefulModBlocks.COMPRESSOR, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> HEAVY_IRON_BLOCK = block(SomethingUsefulModBlocks.HEAVY_IRON_BLOCK, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> HEAVY_GOLD_BLOCK = block(SomethingUsefulModBlocks.HEAVY_GOLD_BLOCK, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> HEAVY_COPPER_BLOCK = block(SomethingUsefulModBlocks.HEAVY_COPPER_BLOCK, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> COMPACT_OBSIDIAN = block(SomethingUsefulModBlocks.COMPACT_OBSIDIAN, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> COMP_OBSI_PICKAXE = REGISTRY.register("comp_obsi_pickaxe", () -> new CompObsiPickaxeItem());
	public static final RegistryObject<Item> TRASH = REGISTRY.register("trash", () -> new TrashItem());
	public static final RegistryObject<Item> BIN = REGISTRY.register("bin", () -> new BinItem());
	public static final RegistryObject<Item> DIRT_GLASS = block(SomethingUsefulModBlocks.DIRT_GLASS, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> STONE_GLASS = block(SomethingUsefulModBlocks.STONE_GLASS, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> DEEP_GLASS = block(SomethingUsefulModBlocks.DEEP_GLASS, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> GHOST_DIRT = block(SomethingUsefulModBlocks.GHOST_DIRT, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> GHOST_STONE = block(SomethingUsefulModBlocks.GHOST_STONE, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> GHOST_DEEP = block(SomethingUsefulModBlocks.GHOST_DEEP, SomethingUsefulModTabs.TAB_SOMETHING_USEFUL);
	public static final RegistryObject<Item> HALF_NETHERRACK = REGISTRY.register("half_netherrack", () -> new HalfNetherrackItem());
	public static final RegistryObject<Item> COAL_CORE = REGISTRY.register("coal_core", () -> new CoalCoreItem());
	public static final RegistryObject<Item> COPPER_NUGGET = REGISTRY.register("copper_nugget", () -> new CopperNuggetItem());
	public static final RegistryObject<Item> GOLD_COIN = REGISTRY.register("gold_coin", () -> new GoldCoinItem());
	public static final RegistryObject<Item> SLIVER_COIN = REGISTRY.register("sliver_coin", () -> new SliverCoinItem());
	public static final RegistryObject<Item> COPPER_COIN = REGISTRY.register("copper_coin", () -> new CopperCoinItem());
	public static final RegistryObject<Item> PHONE = REGISTRY.register("phone", () -> new PhoneItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
