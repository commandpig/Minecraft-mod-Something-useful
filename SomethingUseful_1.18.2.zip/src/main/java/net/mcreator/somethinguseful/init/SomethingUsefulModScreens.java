
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.somethinguseful.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.somethinguseful.client.gui.PhoneGUIScreen;
import net.mcreator.somethinguseful.client.gui.CompressorGUIScreen;
import net.mcreator.somethinguseful.client.gui.BinGUIScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SomethingUsefulModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(SomethingUsefulModMenus.COMPRESSOR_GUI, CompressorGUIScreen::new);
			MenuScreens.register(SomethingUsefulModMenus.BIN_GUI, BinGUIScreen::new);
			MenuScreens.register(SomethingUsefulModMenus.PHONE_GUI, PhoneGUIScreen::new);
		});
	}
}
