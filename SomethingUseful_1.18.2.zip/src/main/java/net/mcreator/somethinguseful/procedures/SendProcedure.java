package net.mcreator.somethinguseful.procedures;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Checkbox;

import net.mcreator.somethinguseful.SomethingUsefulMod;

import java.util.stream.Collectors;
import java.util.List;
import java.util.HashMap;
import java.util.Comparator;
import java.util.ArrayList;

public class SendProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		String messagesFromGUI = "";
		if (!(guistate.containsKey("text:message") ? ((EditBox) guistate.get("text:message")).getValue() : "").isEmpty()) {
			if (guistate.containsKey("checkbox:sendname") ? ((Checkbox) guistate.get("checkbox:sendname")).selected() : false) {
				messagesFromGUI = "Player: " + entity.getDisplayName().getString() + ", ";
			}
			if (guistate.containsKey("checkbox:sendlocation") ? ((Checkbox) guistate.get("checkbox:sendlocation")).selected() : false) {
				messagesFromGUI = messagesFromGUI + "Location: " + (x + ", " + y + ", " + z + ", ");
			}
			messagesFromGUI = messagesFromGUI + "Message: " + (guistate.containsKey("text:message") ? ((EditBox) guistate.get("text:message")).getValue() : "");
			if (guistate.containsKey("checkbox:sendinrange") ? ((Checkbox) guistate.get("checkbox:sendinrange")).selected() : false) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(new Object() {
						double convert(String s) {
							try {
								return Double.parseDouble(s.trim());
							} catch (Exception e) {
							}
							return 0;
						}
					}.convert(guistate.containsKey("text:range") ? ((EditBox) guistate.get("text:range")).getValue() : "") / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
							.collect(Collectors.toList());
					for (Entity entityiterator : _entfound) {
						if (entityiterator instanceof Player _player && !_player.level.isClientSide())
							_player.displayClientMessage(new TextComponent(messagesFromGUI), (false));
					}
				}
			} else {
				for (Entity entityiterator : new ArrayList<>(world.players())) {
					if (entityiterator instanceof Player _player && !_player.level.isClientSide())
						_player.displayClientMessage(new TextComponent(messagesFromGUI), (false));
				}
			}
			SomethingUsefulMod.LOGGER.info(("Send message: \"" + "" + messagesFromGUI + "\" " + ("(" + entity.getDisplayName().getString() + ", " + (x + ", " + y + ", " + z) + ")")));
			if (entity instanceof Player _player)
				_player.closeContainer();
		}
	}
}
